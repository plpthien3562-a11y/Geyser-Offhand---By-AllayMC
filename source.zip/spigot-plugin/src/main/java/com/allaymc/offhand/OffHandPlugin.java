package com.allaymc.offhand;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Main plugin entry point. Tracks which players have the custom off-hand
 * mechanic enabled in a thread-safe {@link ConcurrentHashMap}.
 *
 * <p>Copyright (c) AllayMC. All rights reserved.</p>
 */
public final class OffHandPlugin extends JavaPlugin {

    private final ConcurrentHashMap<UUID, Boolean> enabledPlayers = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(new OffHandListener(this), this);
        getLogger().info("AllayMC OffHand enabled. Copyright (c) AllayMC. All rights reserved.");
    }

    @Override
    public void onDisable() {
        enabledPlayers.clear();
        getLogger().info("AllayMC OffHand disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by a player.");
            return true;
        }
        String name = command.getName().toLowerCase();
        if (name.equals("oha")) {
            enable(player);
            player.sendMessage("§a[AllayMC OffHand] Custom off-hand mechanics §2ENABLED§a. Sneak + double-click to use.");
            return true;
        }
        if (name.equals("oho")) {
            disable(player);
            player.sendMessage("§c[AllayMC OffHand] Custom off-hand mechanics §4DISABLED§c.");
            return true;
        }
        return false;
    }

    public void enable(Player player) {
        enabledPlayers.put(player.getUniqueId(), Boolean.TRUE);
    }

    public void disable(Player player) {
        enabledPlayers.remove(player.getUniqueId());
    }

    public boolean isEnabled(Player player) {
        return enabledPlayers.getOrDefault(player.getUniqueId(), Boolean.FALSE);
    }
}
