package com.allaymc.offhand;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles the sneaking + double-click trigger for custom off-hand actions.
 *
 * <p>Trigger conditions: player has {@code /oha} enabled AND is sneaking AND
 * performs a double-click (two interactions within {@link #DOUBLE_CLICK_WINDOW_MS}
 * milliseconds on the same action type).</p>
 *
 * <p>Off-hand item validations: target items are BLOCKS or WEAPONS. A SHIELD is
 * strictly excluded to preserve vanilla crouching shield-blocking.</p>
 *
 * <p>Copyright (c) AllayMC. All rights reserved.</p>
 */
public final class OffHandListener implements Listener {

    private static final long DOUBLE_CLICK_WINDOW_MS = 400L;
    private static final double ENTITY_REACH = 4.5D;
    private static final double BLOCK_REACH = 5.0D;

    private final OffHandPlugin plugin;

    private final ConcurrentHashMap<UUID, ClickRecord> lastClicks = new ConcurrentHashMap<>();

    OffHandListener(OffHandPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!plugin.isEnabled(player)) {
            return;
        }
        if (!player.isSneaking()) {
            return;
        }

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR
                && action != Action.RIGHT_CLICK_BLOCK
                && action != Action.LEFT_CLICK_AIR
                && action != Action.LEFT_CLICK_BLOCK) {
            return;
        }

        ItemStack offHand = player.getInventory().getItemInOffHand();
        if (offHand == null || offHand.getType() == Material.AIR) {
            return;
        }
        Material offType = offHand.getType();

        // STRICT EXCLUSION: shields bypass all custom logic to preserve vanilla blocking.
        if (offType == Material.SHIELD) {
            return;
        }

        boolean isRight = action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK;
        boolean isLeft = action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK;

        if (!isDoubleClick(player, isRight)) {
            return;
        }

        if (isRight) {
            handleRightClick(player, offHand, offType, event);
        } else if (isLeft) {
            handleLeftClick(player, offHand, offType, event);
        }
    }

    /**
     * Determines whether the current interaction is the second click of a
     * double-click sequence on the same side (right or left).
     */
    private boolean isDoubleClick(Player player, boolean rightSide) {
        UUID id = player.getUniqueId();
        long now = System.currentTimeMillis();
        ClickRecord prev = lastClicks.get(id);
        ClickRecord current = new ClickRecord(now, rightSide);

        lastClicks.put(id, current);

        if (prev == null) {
            return false;
        }
        return prev.rightSide() == rightSide
                && (now - prev.timestamp()) <= DOUBLE_CLICK_WINDOW_MS;
    }

    /**
     * DOUBLE RIGHT-CLICK: place a block from the off-hand at the targeted location.
     */
    private void handleRightClick(Player player, ItemStack offHand, Material offType,
                                  PlayerInteractEvent event) {
        if (!offType.isBlock()) {
            return;
        }

        RayTraceResult blockHit = player.rayTraceBlocks(BLOCK_REACH);
        if (blockHit == null || blockHit.getHitBlock() == null) {
            return;
        }
        Block targetBlock = blockHit.getHitBlock();
        BlockFace face = blockHit.getHitBlockFace();
        if (face == null) {
            face = BlockFace.UP;
        }
        Block placeBlock = targetBlock.getRelative(face);

        if (!placeBlock.getType().isAir()) {
            return;
        }

        org.bukkit.block.data.BlockData data = offType.createBlockData();
        if (!placeBlock.getChunk().isLoaded()) {
            return;
        }
        placeBlock.setBlockData(data);

        if (offHand.getAmount() > 1) {
            offHand.setAmount(offHand.getAmount() - 1);
            player.getInventory().setItemInOffHand(offHand);
        } else {
            player.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
        }

        // Cancel the vanilla interaction so the main-hand item does not also act.
        event.setCancelled(true);
    }

    /**
     * DOUBLE LEFT-CLICK: attack a targeted entity (if any) using the off-hand
     * weapon, otherwise break the targeted block with the off-hand tool.
     */
    private void handleLeftClick(Player player, ItemStack offHand, Material offType,
                                 PlayerInteractEvent event) {
        boolean isWeapon = isWeapon(offType);
        boolean isTool = offType.name().endsWith("_PICKAXE")
                || offType.name().endsWith("_AXE")
                || offType.name().endsWith("_SHOVEL")
                || offType.name().endsWith("_HOE")
                || offType == Material.SHEARS;

        if (!isWeapon && !isTool) {
            return;
        }

        RayTraceResult entityHit = rayTraceEntities(player, ENTITY_REACH);
        if (entityHit != null && entityHit.getHitEntity() instanceof LivingEntity target
                && target != player) {
            attackWithOffHand(player, target, offHand);
            event.setCancelled(true);
            return;
        }

        RayTraceResult blockHit = player.rayTraceBlocks(BLOCK_REACH);
        if (blockHit != null && blockHit.getHitBlock() != null) {
            breakWithOffHand(player, blockHit.getHitBlock(), offHand);
            event.setCancelled(true);
        }
    }

    private RayTraceResult rayTraceEntities(Player player, double reach) {
        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection();
        return world.rayTraceEntities(eye, direction, reach, 0.0D,
                entity -> entity instanceof LivingEntity && entity != player);
    }

    private void attackWithOffHand(Player player, LivingEntity target, ItemStack offHand) {
        double damage = getAttackDamage(offHand.getType());
        if (damage <= 0D) {
            damage = 1D;
        }
        target.damage(damage, player);
    }

    private void breakWithOffHand(Player player, Block block, ItemStack offHand) {
        if (block.getType() == Material.AIR || block.getType().isAir()) {
            return;
        }
        if (block.getType().getHardness() < 0D) {
            return; // Unbreakable (bedrock, barrier, etc.)
        }
        if (player.getGameMode() == org.bukkit.GameMode.SURVIVAL
                || player.getGameMode() == org.bukkit.GameMode.ADVENTURE) {
            block.breakNaturally(offHand);
        } else {
            block.setType(Material.AIR);
        }
    }

    private boolean isWeapon(Material type) {
        return switch (type) {
            case WOODEN_SWORD, STONE_SWORD, IRON_SWORD, GOLDEN_SWORD, DIAMOND_SWORD, NETHERITE_SWORD,
                 WOODEN_AXE, STONE_AXE, IRON_AXE, GOLDEN_AXE, DIAMOND_AXE, NETHERITE_AXE,
                 TRIDENT, BOW, CROSSBOW, MACE -> true;
            default -> false;
        };
    }

    private double getAttackDamage(Material type) {
        return switch (type) {
            case WOODEN_SWORD, GOLDEN_SWORD -> 4D;
            case STONE_SWORD -> 5D;
            case IRON_SWORD -> 6D;
            case DIAMOND_SWORD -> 7D;
            case NETHERITE_SWORD -> 8D;
            case WOODEN_AXE, GOLDEN_AXE -> 7D;
            case STONE_AXE -> 9D;
            case IRON_AXE -> 9D;
            case DIAMOND_AXE -> 9D;
            case NETHERITE_AXE -> 10D;
            case MACE -> 6D;
            case TRIDENT -> 8D;
            default -> 1D;
        };
    }

    private record ClickRecord(long timestamp, boolean rightSide) {}
}
