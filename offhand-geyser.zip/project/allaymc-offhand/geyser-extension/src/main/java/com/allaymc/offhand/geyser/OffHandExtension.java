package com.allaymc.offhand.geyser;

import org.geysermc.event.subscribe.Subscribe;
import org.geysermc.geyser.api.event.bedrock.ClientEmoteEvent;
import org.geysermc.geyser.api.event.lifecycle.GeyserPostInitializeEvent;
import org.geysermc.geyser.api.event.lifecycle.GeyserShutdownEvent;
import org.geysermc.geyser.api.extension.Extension;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Geyser extension that ensures seamless off-hand execution for Bedrock players.
 *
 * <p>The Bedrock client does not natively support the Java edition's off-hand
 * interaction model. When a Bedrock player performs an emote (which we use as the
 * Bedrock-side trigger analogous to the sneaking double-click on Java), this
 * extension requests an off-hand swap from the Java server via
 * {@link org.geysermc.geyser.api.connection.GeyserConnection#requestOffhandSwap()}.
 * This keeps the Bedrock client's inventory view in sync with the server and
 * prevents the client-side de-sync that would otherwise occur.</p>
 *
 * <p>Copyright (c) AllayMC. All rights reserved.</p>
 */
public final class OffHandExtension implements Extension {

    private final Set<UUID> activeConnections = ConcurrentHashMap.newKeySet();

    @Subscribe
    public void onPostInitialize(GeyserPostInitializeEvent event) {
        this.logger().info("AllayMC OffHand Geyser extension loaded. Copyright (c) AllayMC. All rights reserved.");
    }

    @Subscribe
    public void onShutdown(GeyserShutdownEvent event) {
        activeConnections.clear();
    }

    @Subscribe
    public void onEmote(ClientEmoteEvent event) {
        UUID uuid = event.connection().javaUuid();
        if (uuid == null) {
            return;
        }

        // Track the connection as having triggered the off-hand intent.
        activeConnections.add(uuid);

        // Request the off-hand swap from the Java server to keep the Bedrock
        // client's inventory in sync and prevent de-sync.
        event.connection().requestOffhandSwap();

        this.logger().info("Bedrock player " + uuid + " triggered off-hand swap via emote.");
    }

    public boolean isActive(UUID uuid) {
        return activeConnections.contains(uuid);
    }

    public void clear(UUID uuid) {
        activeConnections.remove(uuid);
    }
}
