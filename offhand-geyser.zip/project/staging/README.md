# AllayMC OffHand Package

Copyright (c) AllayMC. All rights reserved.

Custom off-hand mechanics for Paper/Spigot 1.21+ with Geyser-Spigot support.

## Contents

- `jars/AllayMC-OffHand-Spigot-1.0.0.jar` — Paper/Spigot plugin
- `jars/AllayMC-OffHand-Geyser-1.0.0.jar` — Geyser extension
- `source/` — Full Maven multi-module source (parent + spigot-plugin + geyser-extension)

## Requirements

- Java 21+
- Paper/Spigot 1.21+
- Geyser-Spigot (latest) for Bedrock cross-play support

## Installation

1. Place `AllayMC-OffHand-Spigot-1.0.0.jar` in your server's `plugins/` folder.
2. Place `AllayMC-OffHand-Geyser-1.0.0.jar` in your Geyser `extensions/` folder.
3. Restart the server.

## Usage

- `/oha` — Enable custom off-hand mechanics (permission: `allaymc.offhand.use`)
- `/oho` — Disable custom off-hand mechanics

### Trigger Conditions

Activates ONLY when ALL of the following are true:
1. Player has `/oha` enabled
2. Player is sneaking (crouching)
3. Player performs a double-click interaction

### Actions

- **Double right-click** — Places a block from the off-hand at the targeted location (if a block is held)
- **Double left-click** — Attacks a targeted entity or breaks a targeted block using the off-hand weapon/tool

### Off-Hand Item Validations

- Target items: BLOCKS or WEAPONS (Sword, Axe, Mace, etc.)
- **STRICT EXCLUSION**: If the off-hand item is a SHIELD, all custom logic is bypassed to preserve vanilla crouching shield-blocking mechanics.

## Geyser Extension

The Geyser extension intercepts Bedrock emote events (the Bedrock-side trigger analogous to the Java sneaking double-click) and requests an off-hand swap from the Java server via `requestOffhandSwap()`. This keeps the Bedrock client's inventory view in sync with the server, preventing client-side de-sync.

## Build

```bash
mvn clean package
```

Outputs:
- `spigot-plugin/target/AllayMC-OffHand-Spigot-1.0.0.jar`
- `geyser-extension/target/AllayMC-OffHand-Geyser-1.0.0.jar`
