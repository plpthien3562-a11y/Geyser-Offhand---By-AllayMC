package dev.allaymc.offhand;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;

public final class FloodgateBridge {
   private final Object floodgateApi;
   private final Method floodgateIsFloodgatePlayer;
   private final Object geyserApi;
   private final Method geyserIsBedrockPlayer;

   private FloodgateBridge(Object fApi, Method fMethod, Object gApi, Method gMethod) {
      this.floodgateApi = fApi;
      this.floodgateIsFloodgatePlayer = fMethod;
      this.geyserApi = gApi;
      this.geyserIsBedrockPlayer = gMethod;
   }

   public static FloodgateBridge create(Logger log) {
      Object fApi = null;
      Method fM = null;

      try {
         if (Bukkit.getPluginManager().getPlugin("floodgate") != null) {
            Class<?> api = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            fApi = api.getMethod("getInstance").invoke((Object)null);
            fM = api.getMethod("isFloodgatePlayer", UUID.class);
         }
      } catch (Throwable t) {
         log.info("Floodgate API not available: " + t.getMessage());
      }

      Object gApi = null;
      Method gM = null;

      try {
         Class<?> api = Class.forName("org.geysermc.geyser.api.GeyserApi");
         gApi = api.getMethod("api").invoke((Object)null);
         gM = api.getMethod("isBedrockPlayer", UUID.class);
      } catch (Throwable var6) {
      }

      return new FloodgateBridge(fApi, fM, gApi, gM);
   }

   public boolean isBedrockPlayer(UUID id) {
      try {
         if (this.floodgateApi != null && this.floodgateIsFloodgatePlayer != null) {
            Object r = this.floodgateIsFloodgatePlayer.invoke(this.floodgateApi, id);
            if (r instanceof Boolean) {
               Boolean b = (Boolean)r;
               if (b) {
                  return true;
               }
            }
         }

         if (this.geyserApi != null && this.geyserIsBedrockPlayer != null) {
            Object r = this.geyserIsBedrockPlayer.invoke(this.geyserApi, id);
            if (r instanceof Boolean) {
               Boolean b = (Boolean)r;
               return b;
            }
         }
      } catch (Throwable var4) {
      }

      return false;
   }

   public String describe() {
      boolean var10000 = this.floodgateApi != null;
      return "floodgate=" + var10000 + ", geyser=" + (this.geyserApi != null);
   }
}
