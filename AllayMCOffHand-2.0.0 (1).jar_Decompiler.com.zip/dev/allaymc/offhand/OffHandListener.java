package dev.allaymc.offhand;

import java.util.HashMap;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Levelled;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class OffHandListener implements Listener {
   private final AllayMCOffHand plugin;

   public OffHandListener(AllayMCOffHand plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onJoin(PlayerJoinEvent e) {
      this.plugin.handleJoin(e.getPlayer());
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onDrop(PlayerDropItemEvent e) {
      if (this.plugin.isFeaturePlace()) {
         Player p = e.getPlayer();
         UUID id = p.getUniqueId();
         if (this.plugin.isBedrock(id)) {
            if (!p.isInsideVehicle() || this.plugin.allowInVehicle() || this.plugin.isEnabled(id)) {
               ItemStack off = p.getInventory().getItemInOffHand();
               Material m = off == null ? null : off.getType();
               boolean placeable = this.plugin.isValidPlaceable(m);
               boolean scoop = m == Material.BUCKET;
               if (placeable || scoop) {
                  e.setCancelled(true);
                  e.getItemDrop().remove();
                  long now = System.currentTimeMillis();
                  Long prev = (Long)this.plugin.lastInteractMap().put(id, now);
                  if (prev != null && now - prev <= this.plugin.doubleClickWindowMs()) {
                     this.plugin.lastInteractMap().remove(id);
                     if (scoop) {
                        this.scoopFromOffHand(p, off);
                     } else {
                        this.placeFromOffHand(p, off, (Block)null, BlockFace.UP);
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onInteract(PlayerInteractEvent e) {
      if (this.plugin.isFeaturePlace()) {
         if (e.getHand() == EquipmentSlot.HAND) {
            Action a = e.getAction();
            if (a == Action.RIGHT_CLICK_BLOCK || a == Action.RIGHT_CLICK_AIR) {
               Player p = e.getPlayer();
               UUID id = p.getUniqueId();
               if (this.plugin.isEnabled(id)) {
                  if (p.isSneaking()) {
                     if (!p.isInsideVehicle() || this.plugin.allowInVehicle()) {
                        ItemStack off = p.getInventory().getItemInOffHand();
                        Material m = off == null ? null : off.getType();
                        boolean placeable = this.plugin.isValidPlaceable(m);
                        boolean scoop = m == Material.BUCKET;
                        if (placeable || scoop) {
                           long now = System.currentTimeMillis();
                           Long prev = (Long)this.plugin.lastInteractMap().put(id, now);
                           if (prev != null && now - prev <= this.plugin.doubleClickWindowMs()) {
                              this.plugin.lastInteractMap().remove(id);
                              if (scoop) {
                                 this.scoopFromOffHand(p, off);
                              } else {
                                 this.placeFromOffHand(p, off, e.getClickedBlock(), e.getBlockFace());
                              }

                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void placeFromOffHand(Player p, ItemStack off, Block clicked, BlockFace face) {
      Material m = off.getType();
      boolean bucket = AllayMCOffHand.isFluidBucket(m);
      if (bucket || m.isBlock()) {
         Block target = clicked;
         BlockFace f = face != null ? face : BlockFace.UP;
         if (clicked == null) {
            target = p.getTargetBlockExact(5);
            if (target == null) {
               return;
            }

            f = BlockFace.UP;
         }

         Block place = target.getRelative(f);
         if (bucket) {
            if (place.getType().isAir() || place.isLiquid()) {
               Material fluid = m == Material.WATER_BUCKET ? Material.WATER : (m == Material.LAVA_BUCKET ? Material.LAVA : Material.POWDER_SNOW);
               Material before = place.getType();
               place.setType(fluid, true);
               if (place.getType() == fluid) {
                  if (before != fluid) {
                     if (p.getGameMode() != GameMode.CREATIVE) {
                        p.getInventory().setItemInOffHand(new ItemStack(Material.BUCKET));
                     }

                  }
               }
            }
         } else if (place.getType().isAir() || place.isLiquid()) {
            if (!place.getBoundingBox().overlaps(p.getBoundingBox())) {
               Material before = place.getType();
               place.setType(m, true);
               if (place.getType() != before && place.getType() == m) {
                  if (p.getGameMode() != GameMode.CREATIVE) {
                     ItemStack live = p.getInventory().getItemInOffHand();
                     if (live == null || live.getType() != m) {
                        return;
                     }

                     int amt = live.getAmount() - 1;
                     if (amt <= 0) {
                        p.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
                     } else {
                        live.setAmount(amt);
                        p.getInventory().setItemInOffHand(live);
                     }
                  }

               }
            }
         }
      }
   }

   private void scoopFromOffHand(Player p, ItemStack off) {
      if (off != null && off.getType() == Material.BUCKET) {
         Block hit = p.getTargetBlockExact(5);
         if (hit != null) {
            Material src = hit.getType();
            Material filled;
            if (src == Material.WATER) {
               filled = Material.WATER_BUCKET;
            } else {
               if (src != Material.LAVA) {
                  return;
               }

               filled = Material.LAVA_BUCKET;
            }

            BlockData var7 = hit.getBlockData();
            if (var7 instanceof Levelled) {
               Levelled lv = (Levelled)var7;
               if (lv.getLevel() != 0) {
                  return;
               }
            }

            hit.setType(Material.AIR, true);
            if (hit.getType() == Material.AIR) {
               if (p.getGameMode() != GameMode.CREATIVE) {
                  ItemStack live = p.getInventory().getItemInOffHand();
                  if (live == null || live.getType() != Material.BUCKET) {
                     return;
                  }

                  if (live.getAmount() > 1) {
                     live.setAmount(live.getAmount() - 1);
                     p.getInventory().setItemInOffHand(live);
                     HashMap<Integer, ItemStack> leftover = p.getInventory().addItem(new ItemStack[]{new ItemStack(filled)});
                     leftover.values().forEach((it) -> p.getWorld().dropItemNaturally(p.getLocation(), it));
                  } else {
                     p.getInventory().setItemInOffHand(new ItemStack(filled));
                  }
               }

            }
         }
      }
   }
}
